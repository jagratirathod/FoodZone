from django.urls import path
from vender import views
app_name = "vender"

urlpatterns = [
    
    path('',views.homeView.as_view(),name="vender"),
    path('CategoryView/',views.CategoryView.as_view()),
    path('addcat/',views.AddCategory.as_view()),
    path('FoodView/',views.FoodView.as_view()),
    path('FooddeleteView/<int:pk>/',views.FooddeleteView.as_view()),






    
]