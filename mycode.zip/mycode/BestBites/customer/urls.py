from django.urls import path
from customer import views

app_name = "customer"
urlpatterns = [
    path('', views.CustomerView.as_view(), name="customer"),
    path('Filterby/', views.Filterby.as_view()),
    path('ReviewProduct/<int:pk>/', views.ReviewProduct.as_view()),
    path('SingleFood/<int:pk>/', views.SingleFood.as_view()),
    path('payment/', views.payment),
    path('Order/', views.MyOrder.as_view()),
    path('ShowAddress/', views.ShowAddress.as_view()),
    path('Mywishlist/', views.Mywishlist.as_view(), name="wish"),
    path('Fooddelete/<int:pk>/', views.Fooddelete.as_view(), name="delete"),
    path('AddInWishlist/', views.AddInWishlist.as_view()),
    path('SearchView/', views.SearchView.as_view()),
    path('cart_add/<int:id>/', views.cart_add, name='cart_add'),
    path('item_clear/<int:id>/', views.item_clear, name='item_clear'),
    path('item_increment/<int:id>/', views.item_increment, name='item_increment'),
    path('item_decrement/<int:id>/', views.item_decrement, name='item_decrement'),
    path('cart_clear/', views.cart_clear, name='cart_clear'),
    path('cart-detail/', views.cart_detail, name='cart_detail'),
    path('handlerequest/', views.handlerequest, name='handlerequest'),

]
